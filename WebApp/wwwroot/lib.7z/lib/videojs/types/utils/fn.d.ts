export const UPDATE_REFRESH_INTERVAL: 30;
export function bind_(context: any, fn: Function, uid?: number): Function;
export function throttle(fn: Function, wait: number): Function;
export function debounce(func: Function, wait: number, immediate?: boolean, context?: any): Function;
//# sourceMappingURL=fn.d.ts.map